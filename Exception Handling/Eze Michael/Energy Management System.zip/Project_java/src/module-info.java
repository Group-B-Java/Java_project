/**
 * 
 */
/**
 * 
 */
module Project_java {
	requires junit;
}