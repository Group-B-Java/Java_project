package smartDevice.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import smartDevice.smartDeviceC;

public class smartDeviceCTest {

    private ArrayList<Integer> state;
    private ArrayList<Integer> energySource;
    private Lock energyLock;
    private smartDeviceC device;

    @BeforeEach
    public void setup() {
        state = new ArrayList<>();
        energySource = new ArrayList<>();
        energyLock = new ReentrantLock();

        state.add(smartDeviceC.OFF); // Initial state
        energySource.add(100); // Initial energy level

        // Create the device instance
        device = new smartDeviceC(state, energySource, "testDevice", energyLock);
    }




    @Test
    public void testLockBehavior() throws InterruptedException {
        state.set(0, smartDeviceC.ON); // Set device to ON state

        // Run the `on` method in a separate thread
        Thread thread = new Thread(() -> device.on());
        thread.start();

        // Wait for the thread to acquire the lock
        TimeUnit.SECONDS.sleep(1);

        // Check if the lock is held
        assertTrue(energyLock.tryLock(), "Energy lock should be accessible");
        energyLock.unlock(); // Release the lock if acquired

        state.set(0, smartDeviceC.OFF); // Stop the loop
        thread.join(); // Wait for the thread to terminate
    }
}
