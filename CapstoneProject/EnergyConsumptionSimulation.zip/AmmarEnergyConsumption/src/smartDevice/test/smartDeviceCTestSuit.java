package smartDevice.test;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;

// Import the test classes to be included in the suite
//import smartDevice.test.smartDeviceCTest;

@Suite
@SuiteDisplayName("Smart device test")
@SelectClasses({
    smartDeviceCTest.class, // Include your test classes here
    // Add other test classes if needed
})
public class smartDeviceCTestSuit {
    // No code is needed here; the annotations handle everything
}
