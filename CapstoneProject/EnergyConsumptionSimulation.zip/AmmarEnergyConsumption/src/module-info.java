/**
 * 
 */
/**
 * 
 */

module AmmarEnergyConsumption{
	requires java.logging;
	requires org.junit.jupiter.api;
	requires org.junit.platform.suite.api;
}