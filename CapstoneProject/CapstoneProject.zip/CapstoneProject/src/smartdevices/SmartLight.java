package smartdevices;

public class SmartLight extends SmartDevice {
    public SmartLight(String name, double powerUsage) {
        super(name, powerUsage);
    }
}
