package smartdevices;

public class SmartHeater extends SmartDevice {
    public SmartHeater(String name, double powerUsage) {
        super(name, powerUsage);
    }
}
