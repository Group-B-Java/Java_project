package smartdevices;

public class SmartSwitch extends SmartDevice {
    public SmartSwitch(String name, double powerUsage) {
        super(name, powerUsage);
    }
}
