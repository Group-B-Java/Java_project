package smartdevices;

public class SmartTv extends SmartDevice {
    public SmartTv(String name, double powerUsage) {
        super(name, powerUsage);
    }
}
