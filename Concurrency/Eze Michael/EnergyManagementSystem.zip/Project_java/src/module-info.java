/**
 * 
 */
/**
 * 
 */
module Java_Project {
	requires junit;
}